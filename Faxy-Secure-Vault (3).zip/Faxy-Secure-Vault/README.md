# Faxy Secure Vault

A cybersecurity-themed encryption + social system prototype. Single-file demo.

## Run
Open `index.html` in any modern browser. That's it.

All data (users, sessions, activity logs, themes, friends) is stored in your browser's `localStorage`.

## Features
- Login / Sign Up with auto-generated User IDs (FAXY-XXXX)
- File / message encryption simulator (AES, RSA, CRYSTALS-Kyber)
- Simulated file upload, animated processing pipeline, key generation
- Friend network by User ID
- Per-user activity log
- Four themes (Dark Blue, Purple Neon, Green Cyber, Light)
- Account settings + delete

> Note: encryption is simulated for demonstration only. Do not use for real security.
